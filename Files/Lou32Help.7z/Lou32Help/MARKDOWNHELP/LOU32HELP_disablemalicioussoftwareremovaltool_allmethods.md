#       LOU32HELP -- Lou32 Help Module Document
---
# DISABLE MALICIOUS SOFTWARE REMOVAL TOOL (MRT.EXE)
---
## METHOD 1: Navigate To This Key in RegEdit (If Already Exists) or Create This Key (If It Doesn't Exist):

Computer\HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\MRT

## Add D-Word:

DontOfferThroughWUAU

## Set Value of New D-Word:

1

---

## METHOD 2: Disable MRT via Group Policy:

## In Group Policy Editor (gpedit.msc), the relevant policy can be found here:

Computer Configuration\Administrative Templates\Windows Components\Microsoft Malicious Software Removal Tool

## Follow instructions in your Group Policy Editor to enable or disable this group policy, the GP Editor will provide the most up-to-date context and information relevant to your specific Windows installation and version 

---

## METHOD 3: Delete MRT.EXE From System32

This is not recommended, but you can also manually delete the file MRT.exe from %windir%/System32/, however it may still reappear after updates if the above methods are not also used to disable it.

---
# THIS DOCUMENT IS PROVIDED VIA THE LOU32HELP CONTENT DELIVERY APPARATUS
## LOU32HELP IS THE PROPERTY OF LOU32 LOU32HELP SYSTEMS, USE OF THE LOU32HELP MODULE FRAMEWORK, STYLING SCHEMA, AND NAMING CONVENTIONS (INCLUDING ANY LS SHELL MONIKERS ["LSMon", or "LSM", depending on LOU32HELP Version]) ARE THE PROPERTY OF THE AUTHOR, LOUIS 
## End Of Lou32 Help Module Document -- Lou32Help Apparatus
---