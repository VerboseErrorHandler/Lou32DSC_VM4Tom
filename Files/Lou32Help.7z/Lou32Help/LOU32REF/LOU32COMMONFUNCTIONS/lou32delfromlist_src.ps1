﻿$targetFolder = Read-Host -Prompt "Target Folder?"
$fileList = Read-Host -Prompt "File List?"

Get-ChildItem -Path "$targetFolder\*" -Recurse -Include @(Get-Content $fileList) | Remove-Item -Verbose