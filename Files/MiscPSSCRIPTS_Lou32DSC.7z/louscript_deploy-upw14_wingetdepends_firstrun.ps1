Invoke-WebRequest `
    -URI https://aka.ms/Microsoft.VCLibs.x64.14.00.Desktop.appx `
    -OutFile UWPDesktop.appx -UseBasicParsing
Add-AppxPackage UWPDesktop.appx
Remove-Item UWPDesktop.appx